using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Json : MonoBehaviour
{
    //public Text nome;
    //public Text senha;

    //public void Gravar()
    //{

    //    Usuario user = new Usuario();
    //    user.login = name.text;
    //    user.senha = name.text;

    //    print("Login: " + user.login);
    //    print("Senha: " + user.senha);

    //}

    //string json = "";

    //string filePath




    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

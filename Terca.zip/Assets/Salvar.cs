using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Salvar
{

    public float x;
    public float y;
    public float z;
    public float pontos;

}

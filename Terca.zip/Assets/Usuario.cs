using UnityEngine;

public class Usuario
{

    public string login;
    public string password;
    public string senha;




}
